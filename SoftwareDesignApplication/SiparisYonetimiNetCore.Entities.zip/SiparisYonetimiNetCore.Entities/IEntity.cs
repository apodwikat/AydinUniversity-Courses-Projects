﻿namespace SiparisYonetimiNetCore.Entities
{
    public interface IEntity
    {
        public int Id { get; set; }
    }
}
