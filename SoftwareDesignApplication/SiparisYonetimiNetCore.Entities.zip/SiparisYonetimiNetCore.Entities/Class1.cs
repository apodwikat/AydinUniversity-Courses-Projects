﻿namespace SiparisYonetimiNetCore.Entities
{
    class Class1
    {
    }
}
