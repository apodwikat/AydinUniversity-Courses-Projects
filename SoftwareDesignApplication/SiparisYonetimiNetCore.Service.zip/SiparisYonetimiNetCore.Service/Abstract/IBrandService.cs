﻿using SiparisYonetimiNetCore.Data.Abstract;

namespace SiparisYonetimiNetCore.Service.Abstract
{
    public interface IBrandService : IBrandRepository
    {
    }
}
