﻿using SiparisYonetimiNetCore.Data.Abstract;

namespace SiparisYonetimiNetCore.Service.Abstract
{
    public interface ICategoryService : ICategoryRepository
    {
    }
}
